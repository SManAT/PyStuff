import sys

from PySide6.QtWidgets import QApplication
from ui.MainWindow import MainWindow


# Run pylint --generate-rcfile > .pylintrc and set
# extension-pkg-whitelist=PySide6
# also set in Preferences > Pylint the rc file

if __name__ == "__main__":
    app = QApplication(sys.argv)
    # app.setWindowIcon(QIcon("icon.ico"))
    # app.setStyleSheet(qdarktheme.load_stylesheet())
    mainWindow = MainWindow()
    mainWindow.ui.show()
    app.exec()
