import logging
import os
from pathlib import Path

from PyQt6 import uic
from PyQt6.QtGui import QIcon
from PySide6 import QtWidgets, QtGui
import qdarktheme


# Design in normal Mode > Stylesheet will be applied during run
class MainWindow(QtWidgets.QDialog):
    """ The Main Window """

    def __init__(self):
        QtWidgets.QDialog.__init__(self)
        self.logger = logging.getLogger(__name__)
        uic.uiparser.logger.setLevel(logging.INFO)
        uic.properties.logger.setLevel(logging.INFO)
        # rootDir of Application
        self.rootDir = Path(__file__).parent.parent
        self._initUi()

    def _initUi(self):
        uifile = self.rootDir.joinpath('ui/main.ui')
        self.ui = uic.loadUi(uifile)

        # apply qdarktheme
        self.ui.setStyleSheet(qdarktheme.load_stylesheet())

        self.ui.setWindowTitle("My App")

        iconfile = os.path.join(self.rootDir, 'App.png')
        print(iconfile)

        self.ui.setWindowIcon(QIcon(iconfile))
