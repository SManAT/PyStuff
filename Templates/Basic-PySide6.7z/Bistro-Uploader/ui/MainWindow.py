import logging
from pathlib import Path

from PyQt6 import uic
from PySide6 import QtWidgets
from PySide6.QtCore import QFile
from PySide6.QtUiTools import QUiLoader
from PySide6.QtWidgets import QMainWindow
import qdarktheme


# Design in normal Mode > Stylesheet will be applied during run
class MainWindow(QtWidgets.QDialog):
    """ The Main Window """

    def __init__(self):
        QtWidgets.QDialog.__init__(self)
        self.logger = logging.getLogger(__name__)
        uic.uiparser.logger.setLevel(logging.INFO)
        uic.properties.logger.setLevel(logging.INFO)
        # rootDir of Application
        self.rootDir = Path(__file__).parent.parent
        self._initUi()

    def _initUi(self):
        self.setWindowTitle("My App")
        uifile = self.rootDir.joinpath('ui/main.ui')

        #iconfile = self.rootDir.joinpath('pixmaps/windowicon.png').as_posix()
        # self.ui.setWindowIcon(QIcon(iconfile))

        self.ui = uic.loadUi(uifile)

        self.ui.setStyleSheet(qdarktheme.load_stylesheet())
